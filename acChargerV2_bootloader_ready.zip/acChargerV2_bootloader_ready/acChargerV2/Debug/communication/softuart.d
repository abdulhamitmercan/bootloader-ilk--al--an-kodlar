# FIXED

communication/softuart.obj: ../communication/softuart.c
communication/softuart.obj: ../communication/softuart.h
communication/softuart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/stdbool.h
communication/softuart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/_ti_config.h
communication/softuart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/linkage.h
communication/softuart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/stdint.h
communication/softuart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/_stdint40.h
communication/softuart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/sys/stdint.h
communication/softuart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/sys/cdefs.h
communication/softuart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/sys/_types.h
communication/softuart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/machine/_types.h
communication/softuart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/machine/_stdint.h
communication/softuart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/sys/_stdint.h
communication/softuart.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430.h
communication/softuart.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430f67751.h
communication/softuart.obj: C:/ti/ccs2100/ccs/ccs_base/msp430/include/in430.h
communication/softuart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics.h
communication/softuart.obj: C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics_legacy_undefs.h

../communication/softuart.c:

../communication/softuart.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/stdbool.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/_ti_config.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/linkage.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/stdint.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/_stdint40.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/sys/stdint.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/sys/cdefs.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/sys/_types.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/machine/_types.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/machine/_stdint.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/sys/_stdint.h:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430.h:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/msp430f67751.h:

C:/ti/ccs2100/ccs/ccs_base/msp430/include/in430.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics.h:

C:/ti/ccs2100/ccs/tools/compiler/ti-cgt-msp430_21.6.2.LTS/include/intrinsics_legacy_undefs.h:

